/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unpa.controlescolar;

import java.util.LinkedList;

/**
 *
 * @author cardo
 */
public class GestionarGrupos extends ControladorBase<Grupo> {
    private BDGruposMYSQL bdGrupos;

    public GestionarGrupos() {
        bdGrupos = new BDGruposMYSQL();
    }

    @Override
    protected boolean agregar(Grupo grupo) {
        return bdGrupos.registrar(grupo);
    }

    @Override
    protected boolean editar(Grupo grupo) {
        return bdGrupos.actualizar(grupo);
    }

    @Override
    protected boolean eliminar(int idGrupo) {
        return bdGrupos.eliminar(idGrupo);
    }
    @Override
    protected Grupo obtener(int idGrupo) {
        return bdGrupos.obtener(idGrupo);
    }

    @Override
    protected LinkedList<Grupo> obtenerTodos() {
        return bdGrupos.obtenerTodos();
    }
}