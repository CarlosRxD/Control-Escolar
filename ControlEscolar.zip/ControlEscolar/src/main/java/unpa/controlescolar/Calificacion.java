/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unpa.controlescolar;

/**
 *
 * @author cardo
 */
// Clase Calificacion
public class Calificacion {
    private int id;
    private int idAlumno;
    private String materia;
    private float calificacion;

    // Constructor
    public Calificacion(int id, int idAlumno, String materia, float calificacion) {
        this.id = id;
        this.idAlumno = idAlumno;
        this.materia = materia;
        this.calificacion = calificacion;
    }
    public Calificacion(int idAlumno, String materia, float calificacion) {
        this.idAlumno = idAlumno;
        this.materia = materia;
        this.calificacion = calificacion;
    }

    // Getters y Setters
    // Getters
    public int getId() {
        return id;
    }

    public int getIdAlumno() {
        return idAlumno;
    }

    public String getMateria() {
        return materia;
    }

    public float getCalificacion() {
        return calificacion;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setIdAlumno(int idAlumno) {
        this.idAlumno = idAlumno;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }
}

