package unpa.controlescolar;

import java.util.LinkedList;

/**
 *
 * @author cardo
 */
public class GestionarMaterias  extends ControladorBase<Materia> {
    private BDMateriasMYSQL bdMaterias;

    public GestionarMaterias() {
        bdMaterias = new BDMateriasMYSQL();
    }
@Override
    protected Materia obtener(int idMateria) {
        return bdMaterias.obtener(idMateria);
    }
    @Override
    protected boolean agregar(Materia materia) {
        return bdMaterias.registrar(materia);
    }

    @Override
    protected boolean editar(Materia materia) {
        return bdMaterias.actualizar(materia);
    }

    @Override
    protected boolean eliminar(int idMateria) {
        return bdMaterias.eliminar(idMateria);
    }

    @Override
    protected LinkedList<Materia> obtenerTodos() {
        return bdMaterias.obtenerTodos();
    }
}
