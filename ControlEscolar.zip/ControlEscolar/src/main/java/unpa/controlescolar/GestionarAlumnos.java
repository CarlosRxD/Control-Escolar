package unpa.controlescolar;

import java.util.LinkedList;

/**
 *
 * @author cardo
 */
public class GestionarAlumnos extends ControladorBase<Alumno> {

    private BDAlumnosMYSQL bdAlumnos;

    public GestionarAlumnos() {
        bdAlumnos = new BDAlumnosMYSQL();
    }
    @Override
    protected Alumno obtener(int idAlumno) {
        return bdAlumnos.obtener(idAlumno);
    }
    @Override
    protected boolean agregar(Alumno alumno) {
        return bdAlumnos.registrar(alumno);
    }

    @Override
    protected boolean editar(Alumno alumno) {
        return bdAlumnos.actualizar(alumno);
    }

    @Override
    protected boolean eliminar(int idAlumno) {
        return bdAlumnos.eliminar(idAlumno);
    }

    @Override
    protected LinkedList<Alumno> obtenerTodos() {
        return bdAlumnos.obtenerTodos();
    }
}

