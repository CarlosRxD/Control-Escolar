package unpa.controlescolar;

import java.util.LinkedList;
import static unpa.controlescolar.ModeloMaterias.obtenerTodo;

/**
 *
 * @author cardo
 */
public class ModeloCalificaciones {

    private static final GestionarCalificaciones controladorCalificaciones = new GestionarCalificaciones();
    private static final GestionarAlumnos controladorAlumnos = new GestionarAlumnos();

    private static final GestionarMaterias controladorMaterias = new GestionarMaterias();

    public static void agregar(int idAlumno, String materia, float calificacion) {
        Calificacion c = new Calificacion(idAlumno, materia, calificacion);
        controladorCalificaciones.agregar(c);
    }

    public static void eliminar(int id) {
        controladorCalificaciones.eliminar(id);
    }

    public static void actualizar(int id, int idAlumno, String materia, float calificacion) {
        Calificacion c = new Calificacion(id, idAlumno, materia, calificacion);
        controladorCalificaciones.editar(c);
    }

    public static String obtenerTodo() {
        LinkedList<Calificacion> calificaciones = controladorCalificaciones.obtenerTodos();

        StringBuilder tabla = new StringBuilder();
        String option = ModeloMaterias.obtenerTodo();
        if (calificaciones != null) {
            for (Calificacion c : calificaciones) {

                Alumno alumno = controladorAlumnos.obtener(c.getIdAlumno());
                tabla.append("<tr>")
                        .append("<td>").append(alumno.getNombre()).append("</td>")
                        .append("<td>").append(c.getMateria()).append("</td>")
                        .append("<td>").append(c.getCalificacion()).append("</td>")
                        .append("<td>")
                        .append("<form method=\"post\" action=\"actualizarCalificacion.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtid\" name=\"txtid\" value=\"" + c.getId() + "\">")
                        .append("<input class = \"btn btn-success\" type=\"submit\" value=\"Editar\">")
                        .append("</form>")
                        .append("<form method=\"post\" action=\"eliminarCalificacion.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + c.getId() + "\">")
                        .append("<input class = \"btn btn-danger\" type=\"submit\" value=\"Eliminar\">")
                        .append("</form>")
                        .append("</td>")
                        .append("</tr>");
            }
        }
        return tabla.toString();
    }

    public static String obtenerActualizar(int id) {
        Calificacion c = controladorCalificaciones.obtener(id);
        Alumno alumno = controladorAlumnos.obtener(c.getIdAlumno());

        StringBuilder formulario = new StringBuilder();
        String option = ModeloMaterias.obtenerTodo();
        LinkedList<Materia> materias = controladorMaterias.obtenerTodos();
        int idMateria = 0;
        for (Materia materia : materias) {
            if (materia.getNombre().equals(c.getMateria())) {
                idMateria = materia.getId();
                break;
            }
        }
        formulario.append("<tr>")
                .append("<td>").append(alumno.getNombre()).append("</td>")
                .append("<input type=\"hidden\" class=\"form-control\" id=\"alumnos\" name=\"alumnos\" value=\"" + c.getIdAlumno()+ "\">\n")
                .append("<select class=\"form-control\" id=\"materias\" name=\"materias\">\n")
                .append("    <option value=\"" + idMateria + "\">" + c.getMateria() + "</option>\n")
                .append(option)
                .append("</select>\n")
                .append("<label for=\"calificaciones\">Nombre:</label>\n")
                .append("<input type=\"number\" class=\"form-control\" id=\"calificaciones\" name=\"calificaciones\" value=\"" + c.getCalificacion() + "\">\n")
                .append("<td>");

        return formulario.toString();
    }

    public static String obtenerAlumnos() {
        LinkedList<Alumno> alumnos = controladorAlumnos.obtenerTodos();
        String option = "";
        for (Alumno alumno : alumnos) {
            option += "<option value=" + alumno.getId() + ">" + alumno.getNombre() + "</option>";
        }
        return option;
    }

    public static String registrar() {
        StringBuilder tabla = new StringBuilder();
        String alumnos = obtenerAlumnos();
        String materias = ModeloMaterias.obtenerTodo();
        tabla.append("<tr>")
                .append("<td><select class=\"form-control\" id=\"alumnos\" name=\"alumnos\">\n")
                .append(alumnos)
                .append("</select></td>\n")
                .append("<td><select class=\"form-control\" id=\"materias\" name=\"materias\">\n")
                .append(materias)
                .append("</select></td>\n")
                .append("<td><input type=\"number\" class=\"form-control\" id=\"calificaciones\" name=\"calificaciones\"></td>\n")
                .append("</tr>");
        return tabla.toString();
    }

    public static void registrarCalificacion(int idAlumno, int materiaId, float calificacion) {
        String materiaNombre = obtenerMateriaNombre(materiaId);
        agregar(idAlumno, materiaNombre, calificacion);
    }

    public static void editarCalificacion(int id, int idAlumno, int materiaId, float calificacion) {
        String materiaNombre = obtenerMateriaNombre(materiaId);
        actualizar(id, idAlumno, materiaNombre, calificacion);
    }

    public static String obtenerMateriaNombre(int materiaId) {
        LinkedList<Materia> materias = controladorMaterias.obtenerTodos();
        String materiaNombre = "";
        for (Materia materia : materias) {
            if (materia.getId() == materiaId) {
                materiaNombre = materia.getNombre();
                break;
            }
        }
        return materiaNombre;
    }
}
