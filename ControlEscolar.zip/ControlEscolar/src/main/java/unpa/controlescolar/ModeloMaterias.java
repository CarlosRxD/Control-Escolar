/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unpa.controlescolar;

import java.text.SimpleDateFormat;
import java.util.LinkedList;

/**
 *
 * @author cardo
 */
public class ModeloMaterias {

    private static final GestionarMaterias controladorMaterias = new GestionarMaterias();

    public static String obtenerTodo() {
        LinkedList<Materia> materias = controladorMaterias.obtenerTodos();
        String option = "";
        for (Materia materia : materias) {
            option += "<option value=" + materia.getId() + ">" + materia.getNombre() + "</option>";
        }
        return option;
    }

    public static void agregar(String nombre) {
        Materia materia = new Materia(nombre);
        controladorMaterias.agregar(materia);
    }

    public static void eliminar(int id) {
        controladorMaterias.eliminar(id);
    }

    public static void actualizar(int id, String nombre) {
        Materia materia = new Materia(id, nombre);
        controladorMaterias.editar(materia);
    }

    public static String obtenerTodos() {
        LinkedList<Materia> materias = controladorMaterias.obtenerTodos();
        StringBuilder tabla = new StringBuilder();

        if (materias != null) {
            for (Materia materia : materias) {

                tabla.append("<tr>")
                        .append("<td>").append(materia.getNombre()).append("</td>")
                        .append("<td>")
                        .append("<form method=\"post\" action=\"actualizarMateria.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + materia.getId() + "\">")
                        .append("<input class = \"btn btn-warning\" type=\"submit\" value=\"Editar \">")
                        .append("</form>")
                        .append("<form method=\"post\" action=\"eliminarMateria.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + materia.getId() + "\">")
                        .append("<input class = \"btn btn-danger\" type=\"submit\" value=\"Eliminar\">")
                        .append("</form>")
                        .append("</td>")
                        .append("</tr>");
            }
        }
        return tabla.toString();
    }

    public static String obtenerActualizar(int id) {
        Materia materia = controladorMaterias.obtener(id);

        StringBuilder formulario = new StringBuilder();
        formulario.append("<label for=\"nombre\">Nombre:</label>\n");
        formulario.append("<input type=\"text\" class=\"form-control\" id=\"nombre\" name=\"nombre\" value=\"" + materia.getNombre() + "\" >\n");
        return formulario.toString();
    }
}
