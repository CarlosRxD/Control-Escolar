/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unpa.controlescolar;

/**
 *
 * @author cardo
 */
// Clase Materia
public class Materia { 
    private int id;
    private String nombre;

    // Constructor
    public Materia(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }
    public Materia( String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    // Getters y Setters
    // Getters
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
