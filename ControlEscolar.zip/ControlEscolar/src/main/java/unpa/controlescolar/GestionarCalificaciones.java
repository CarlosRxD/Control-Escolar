/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unpa.controlescolar;

import java.util.LinkedList;

/**
 *
 * @author cardo
 */
public class GestionarCalificaciones extends ControladorBase<Calificacion> {
    private BDCalificacionesMYSQL bdCalificaciones;

    public GestionarCalificaciones() {
        bdCalificaciones = new BDCalificacionesMYSQL();
    }
    @Override
    protected Calificacion obtener(int idCalificacion) {
        return bdCalificaciones.obtener(idCalificacion);
    }

    @Override
    protected boolean agregar(Calificacion calificacion) {
        return bdCalificaciones.registrar(calificacion);
    }

    @Override
    protected boolean editar(Calificacion calificacion) {
        return bdCalificaciones.actualizar(calificacion);
    }

    @Override
    protected boolean eliminar(int idCalificacion) {
        return bdCalificaciones.eliminar(idCalificacion);
    }

    @Override
    protected LinkedList<Calificacion> obtenerTodos() {
        return bdCalificaciones.obtenerTodos();
    }
}
