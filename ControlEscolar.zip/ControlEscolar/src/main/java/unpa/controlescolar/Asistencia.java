/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unpa.controlescolar;
import java.util.Date;
/**
 *
 * @author cardo
 */
// Clase Asistencia
public class Asistencia {
    private int id;
    private int idAlumno;
    private Date fecha;
    private boolean presente;

    // Constructor
    public Asistencia(int id, int idAlumno, Date fecha, boolean presente) {
        this.id = id;
        this.idAlumno = idAlumno;
        this.fecha = fecha;
        this.presente = presente;
    }
    public Asistencia(int idAlumno, Date fecha, boolean presente) {
        this.idAlumno = idAlumno;
        this.fecha = fecha;
        this.presente = presente;
    }

    // Getters y Setters
    // Getters
    public int getId() {
        return id;
    }

    public int getIdAlumno() {
        return idAlumno;
    }

    public Date getFecha() {
        return fecha;
    }

    public boolean isPresente() {
        return presente;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setIdAlumno(int idAlumno) {
        this.idAlumno = idAlumno;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setPresente(boolean presente) {
        this.presente = presente;
    }
}

