package unpa.controlescolar;

import java.sql.*;
public class MYSQL implements AutoCloseable {
    private Connection conexion = null;

    public MYSQL() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Error al cargar el controlador JDBC", ex);
        }
    }

    public Connection abrir() {
        try {
            if (conexion == null || conexion.isClosed()) {
                System.out.println("Abriendo conexión...");
                String url = "jdbc:mysql://localhost:3306/control_escolar?user=root&password=12345678&serverTimezone=UTC&useSSL=false";
                conexion = DriverManager.getConnection(url);
                System.out.println("Conexión abierta.");
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Error al abrir la conexión", ex);
        }
        return conexion;
    }

    public void cerrar() {
        if (conexion != null) {
            try {
                System.out.println("Cerrando conexión...");
                conexion.close();
                System.out.println("Conexión cerrada.");
            } catch (SQLException ex) {
                throw new RuntimeException("Error al cerrar la conexión", ex);
            }
        }
    }

    //DELETE INSERT UPDATE
    public boolean ejecutarUpdate(String querySQL) {
        try {
            abrir();
            Statement r = conexion.createStatement();
            if (r.executeUpdate(querySQL) != 0) {
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            cerrar();
        }
        return false;
    }


    public ResultSet ejecutarQuery(String querySQL) {
        try {
            abrir();
            Statement r = conexion.createStatement();
            return r.executeQuery(querySQL);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    @Override
    public void close() {
        cerrar();
    }
}
