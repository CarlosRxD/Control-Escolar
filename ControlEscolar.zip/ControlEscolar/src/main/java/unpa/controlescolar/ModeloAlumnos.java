/**
 *
 * @author cardo
 */
package unpa.controlescolar;

import java.util.LinkedList;

public class ModeloAlumnos {

    private static final GestionarAlumnos controladorAlumnos = new GestionarAlumnos();
    private static final GestionarGrupos controladorGrupos = new GestionarGrupos();
    private static final GestionarAsistencias controladorAsistencias = new GestionarAsistencias();

    public static void agregar(String nombre, String correo, int telefono, int matricula, int edad,
            String sexo, String tutor, int telefonoTutor, int idGrupo) {
        Alumno alumno = new Alumno(nombre, correo, telefono, matricula, edad, sexo, tutor, telefonoTutor, idGrupo);
        controladorAlumnos.agregar(alumno);
    }

    public static void eliminar(int id) {
        controladorAlumnos.eliminar(id);
    }

    public static void actualizar(int id, String nombre, String correo, int telefono, int matricula, int edad,
            String sexo, String tutor, int telefonoTutor, int idGrupo) {
        Alumno alumno = new Alumno(id, nombre, correo, telefono, matricula, edad, sexo, tutor, telefonoTutor, idGrupo);
        controladorAlumnos.editar(alumno);
    }

    public static String obtenerTodo() {
        LinkedList<Alumno> alumnos = controladorAlumnos.obtenerTodos();
        LinkedList<Asistencia> asistencias = controladorAsistencias.obtenerTodos();
        String tabla = "";

        if (alumnos != null) {
            for (Alumno alumno : alumnos) {
                Grupo grupo = controladorGrupos.obtener(alumno.getIdGrupo());
                boolean asistio = false;
                for (Asistencia asistencia : asistencias) {
                    if (asistencia.getIdAlumno() == alumno.getId()) {
                        if( asistencia.isPresente()){
                            asistio =true; 
                        }
                        break;
                    }
                }
                tabla += "<tr>"
                        + "<td>" + (asistio ? "Presente" : "Ausente") + "</td>"
                        + "<td>" + alumno.getId() + "</td>"
                        + "<td>" + alumno.getNombre() + "</td>"
                        + "<td>" + alumno.getCorreo() + "</td>"
                        + "<td>" + alumno.getTelefono() + "</td>"
                        + "<td>" + alumno.getMatricula() + "</td>"
                        + "<td>" + alumno.getEdad() + "</td>"
                        + "<td>" + alumno.getSexo() + "</td>"
                        + "<td>" + alumno.getTutor() + "</td>"
                        + "<td>" + alumno.getTelefonoTutor() + "</td>"
                        + "<td>" + grupo.getNombre() + "</td>"
                        + "<td>"
                        + "<form method=\"post\" action=\"eliminarAlumno.jsp\">"
                        + "<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + alumno.getId() + "\">"
                        + "<input class = \"btn btn-outline-danger\" type=\"submit\" value=\"Eliminar\">"
                        + "</form>"
                        + "<form method=\"post\" action=\"actualizarAlumno.jsp\">"
                        + "<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + alumno.getId() + "\">"
                        + "<input class = \"btn btn-outline-warning\" type=\"submit\" value=\"Actualizar\">"
                        + "</form>"
                        + "</td>"
                        + "</tr>";
            }
        }
        return tabla;
    }

    public static String obtenerActualizar(int id) {
        Alumno alumno = controladorAlumnos.obtener(id);
        Grupo grupo = controladorGrupos.obtener(alumno.getIdGrupo());
        String grupos = ModeloGrupos.obtenerTodo();

        StringBuilder formulario = new StringBuilder();
        formulario.append("<label for=\"nombre\">Nombre:</label>\n");
        formulario.append("<input type=\"text\" class=\"form-control\" id=\"nombre\" name=\"nombre\" value=\"" + alumno.getNombre() + "\">\n");
        formulario.append("<label for=\"correo\">Correo:</label>\n");
        formulario.append("<input type=\"text\" class=\"form-control\" id=\"correo\" name=\"correo\" value=\"" + alumno.getCorreo() + "\">\n");
        formulario.append("<label for=\"telefono\">Teléfono:</label>\n");
        formulario.append("<input type=\"number\" class=\"form-control\" id=\"telefono\" name=\"telefono\" value=\"" + alumno.getTelefono() + "\">\n");
        formulario.append("<label for=\"matricula\">Matricula:</label>\n");
        formulario.append("<input type=\"number\" class=\"form-control\" id=\"matricula\" name=\"matricula\" value=\"" + alumno.getMatricula() + "\">\n");
        formulario.append("<label for=\"edad\">Edad:</label>\n");
        formulario.append("<input type=\"number\" class=\"form-control\" id=\"edad\" name=\"edad\" value=\"" + alumno.getEdad() + "\">\n");
        formulario.append("<label for=\"sexo\">Sexo:</label>\n");
        formulario.append("<select class=\"form-control\" id=\"sexo\" name=\"sexo\">\n");
        formulario.append("    <option value=\"" + alumno.getSexo() + "\">" + alumno.getSexo() + "</option>\n");
        formulario.append("    <option value=\"Hombre\">Hombre</option>\n");
        formulario.append("    <option value=\"Mujer\">Mujer</option>\n");
        formulario.append("</select>\n");
        formulario.append("<label for=\"tutor\">Tutor:</label>\n");
        formulario.append("<input type=\"text\" class=\"form-control\" id=\"tutor\" name=\"tutor\" value=\"" + alumno.getTutor() + "\">\n");
        formulario.append("<label for=\"telefonoTutor\">Teléfono del Tutor:</label>\n");
        formulario.append("<input type=\"number\" class=\"form-control\" id=\"telefonoTutor\" name=\"telefonoTutor\" value=\"" + alumno.getTelefonoTutor() + "\">\n");
        formulario.append("<label for=\"grupo\">Grupo:</label>\n");
        formulario.append("<select class=\"form-control\" id=\"grupo\" name=\"grupo\">\n");
        formulario.append("<option value=\"" + alumno.getIdGrupo() + "\">" + grupo.getNombre() + "</option>\n");
        formulario.append(grupos);
        formulario.append("</select>\n");

        return formulario.toString();
    }

    public static LinkedList<Alumno> obtenerPorGrupo(int idGrupo) {
        LinkedList<Alumno> alumnos = controladorAlumnos.obtenerTodos();
        LinkedList<Alumno> alumnosFiltrados = new LinkedList<Alumno>();

        for (Alumno alumno : alumnos) {
            if (alumno.getIdGrupo() == idGrupo) {
                alumnosFiltrados.add(alumno);
            }
        }

        return alumnosFiltrados;
    }

    public static String obtenerAlumnosFiltrados(int idGrupo) {
        LinkedList<Alumno> alumnos = obtenerPorGrupo(idGrupo);
        StringBuilder tabla = new StringBuilder();

        if (alumnos != null) {
            for (Alumno alumno : alumnos) {
                Grupo grupo = controladorGrupos.obtener(alumno.getIdGrupo());
                tabla.append("<tr>")
                        .append("<td>Asistencia</td>")
                        .append("<td>").append(alumno.getId()).append("</td>")
                        .append("<td>").append(alumno.getNombre()).append("</td>")
                        .append("<td>").append(alumno.getCorreo()).append("</td>")
                        .append("<td>").append(alumno.getTelefono()).append("</td>")
                        .append("<td>").append(alumno.getMatricula()).append("</td>")
                        .append("<td>").append(alumno.getEdad()).append("</td>")
                        .append("<td>").append(alumno.getSexo()).append("</td>")
                        .append("<td>").append(alumno.getTutor()).append("</td>")
                        .append("<td>").append(alumno.getTelefonoTutor()).append("</td>")
                        .append("<td>").append(grupo.getNombre()).append("</td>")
                        .append("<td>")
                        .append("<form method=\"post\" action=\"eliminarAlumno.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"").append(alumno.getId()).append("\">")
                        .append("<input class=\"btn-danger\" type=\"submit\" value=\"Eliminar\">")
                        .append("</form>")
                        .append("<form method=\"post\" action=\"actualizarAlumno.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"").append(alumno.getId()).append("\">")
                        .append("<input class=\"btn-warning\" type=\"submit\" value=\"Actualizar\">")
                        .append("</form>")
                        .append("</td>")
                        .append("</tr>");
            }
        }
        return tabla.toString();
    }

}
