package unpa.controlescolar;

import java.sql.*;
import java.util.LinkedList;

public class BDCalificacionesMYSQL {

    public LinkedList<Calificacion> obtenerTodos() {
        String sql = "SELECT * FROM Calificaciones";
        LinkedList<Calificacion> lista = null;
        MYSQL mysql = new MYSQL();
        ResultSet r = mysql.ejecutarQuery(sql);
        if (r != null) {
            try {
                lista = new LinkedList<>();
                while (r.next()) {
                    int id = r.getInt("id");
                    int idAlumno = r.getInt("id_alumno");
                    String materia = r.getString("materia");
                    float calificacion = r.getFloat("calificacion");

                    lista.add(new Calificacion(id, idAlumno, materia, calificacion));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return lista;
    }

    public Calificacion obtener(int id) {
        String sql = "SELECT * FROM Calificaciones WHERE id=" + id;
        MYSQL mysql = new MYSQL();
        ResultSet r = mysql.ejecutarQuery(sql);
        Calificacion c = null;
        try {
            if (r.next()) {
                int idAlumno = r.getInt("id_alumno");
                String materia = r.getString("materia");
                float calificacion = r.getFloat("calificacion");
                c = new Calificacion(id, idAlumno, materia, calificacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return c;
    }

    public boolean eliminar(int idCalificacion) {
        String sql = "DELETE FROM Calificaciones WHERE id=" + idCalificacion;
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean actualizar(Calificacion calificacion) {
        String sql = "UPDATE Calificaciones SET id_alumno="
                + calificacion.getIdAlumno() + ", materia='"
                + calificacion.getMateria() + "', calificacion="
                + calificacion.getCalificacion() + " WHERE id="
                + calificacion.getId();
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean registrar(Calificacion calificacion) {
        String sql = "INSERT INTO Calificaciones (id_alumno, materia, calificacion) VALUES ("
                + calificacion.getIdAlumno() + ",'"
                + calificacion.getMateria() + "',"
                + calificacion.getCalificacion() + ")";
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }
}
