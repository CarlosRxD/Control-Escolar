package unpa.controlescolar;

/**
 *
 * @author cardo
 */
// Clase Alumno
public class Alumno {

    private int id;
    private String nombre;
    private String correo;
    private int telefono;
    private int matricula;
    private int edad;
    private String sexo;
    private String tutor;
    private int telefonoTutor;

    private int idGrupo;

    // Constructor
    public Alumno(String nombre, String correo, int telefono, int matricula, int edad,
            String sexo, String tutor, int telefonoTutor, int idGrupo) {
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.matricula = matricula;
        this.edad = edad;
        this.sexo = sexo;
        this.tutor = tutor;
        this.telefonoTutor = telefonoTutor;
        this.idGrupo = idGrupo;
    }
    public Alumno(int id, String nombre, String correo, int telefono, int matricula, int edad,
            String sexo, String tutor, int telefonoTutor, int idGrupo) {
        this.id=id;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.matricula = matricula;
        this.edad = edad;
        this.sexo = sexo;
        this.tutor = tutor;
        this.telefonoTutor = telefonoTutor;
        this.idGrupo = idGrupo;
    }

    // Getters y Setters (Métodos de acceso)
    // Getters
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getTutor() {
        return tutor;
    }

    public int getTelefonoTutor() {
        return telefonoTutor;
    }

    public int getMatricula() {
        return matricula;
    }

    public int getEdad() {
        return edad;
    }

    public String getSexo() {
        return sexo;
    }

    public int getIdGrupo() {
        return idGrupo;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setTutor(String tutor) {
        this.tutor = tutor;
    }

    public void setTelefonoTutor(int telefonoTutor) {
        this.telefonoTutor = telefonoTutor;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public void setIdGrupo(int idGrupo) {
        this.idGrupo = idGrupo;
    }
}
