package unpa.controlescolar;

import java.util.LinkedList;

public class prueba {

    public static void main(String[] args) {
        GestionarAlumnos controladorAlumnos = new GestionarAlumnos();
        GestionarGrupos controladorGrupos = new GestionarGrupos();

        Alumno alumno = new Alumno("Kary","correo@gmail",12345,21010102,21,"M","Inocencia",12345,2);
        //Grupo grupo = new Grupo("Grupo B");
        //boolean resultadoGrupo = controladorGrupos.agregar(grupo);
        // Guardar el alumno en la base de datos
        boolean resultadoAlumno = controladorAlumnos.agregar(alumno);
        // Guardar el grupo en la base de datos
       //// LinkedList<Grupo> lista = controladorGrupos.obtenerTodos();
       // for (Grupo grupo : lista) {
     //       System.out.println(grupo.getNombre());
       // }

        System.out.println("resultadoAlumno = "+resultadoAlumno);
        // Aquí podrías agregar código para manejar el resultado de la operación de guardado
    }
}
