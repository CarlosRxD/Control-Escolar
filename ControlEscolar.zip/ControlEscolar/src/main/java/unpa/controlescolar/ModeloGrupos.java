package unpa.controlescolar;

import java.util.LinkedList;

/**
 *
 * @author cardo
 */
public class ModeloGrupos {

    private static final GestionarGrupos controladorGrupos = new GestionarGrupos();
    public static String obtenerActualizar(int id) {
        Grupo grupo = controladorGrupos.obtener(id);

        StringBuilder formulario = new StringBuilder();
        formulario.append("<label for=\"nombre\">Nombre:</label>\n");
        formulario.append("<input type=\"text\" class=\"form-control\" id=\"nombre\" name=\"nombre\" value=\"" + grupo.getNombre() + "\" >\n");
        return formulario.toString();
    }
    public static String obtenerTodo() {
        LinkedList<Grupo> grupos = controladorGrupos.obtenerTodos();
        String option = "";
        for (Grupo grupo : grupos) {
            option += "<option value="+grupo.getId()+ ">"+grupo.getNombre() + "</option>";
        }
        return option;
    }
    public static void agregar(String nombre) {
        Grupo grupo = new Grupo(nombre);
        controladorGrupos.agregar(grupo);
    }

    public static void eliminar(int id) {
        controladorGrupos.eliminar(id);
    }

    public static void actualizar(int id,String nombre) {
        Grupo grupo = new Grupo(id,nombre);
        controladorGrupos.editar(grupo);
    }
    public static String obtenerTodos() {
       LinkedList<Grupo> grupos = controladorGrupos.obtenerTodos();
        StringBuilder tabla = new StringBuilder();
        
        if (grupos != null) {
            for (Grupo grupo : grupos) {
                  
                tabla.append("<tr>")
                        .append("<td>").append(grupo.getNombre()).append("</td>")
                        .append("<td>")
                        .append("<form method=\"post\" action=\"actualizarGrupo.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + grupo.getId() + "\">")
                        .append("<input class = \"btn btn-warning\" type=\"submit\" value=\"Editar \">")
                        .append("</form>")
                        .append("<form method=\"post\" action=\"eliminarGrupo.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + grupo.getId() + "\">")
                        .append("<input class = \"btn btn-danger\" type=\"submit\" value=\"Eliminar\">")
                        .append("</form>")
                        .append("</td>")
                        .append("</tr>");
            }
        }
        return tabla.toString();
    }
}
