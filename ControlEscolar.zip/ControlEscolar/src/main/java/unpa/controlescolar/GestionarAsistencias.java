package unpa.controlescolar;

import java.util.LinkedList;

/**
 *
 * @author cardo
 */
public class GestionarAsistencias  extends ControladorBase<Asistencia> {
    private BDAsistenciasMYSQL bdAsistencias;

    public GestionarAsistencias() {
        bdAsistencias = new BDAsistenciasMYSQL();
    }
@Override
    protected Asistencia obtener(int idAsistencia) {
        return bdAsistencias.obtener(idAsistencia);
    }
    @Override
    protected boolean agregar(Asistencia asistencia) {
        return bdAsistencias.registrar(asistencia);
    }

    @Override
    protected boolean editar(Asistencia asistencia) {
        return bdAsistencias.actualizar(asistencia);
    }

    @Override
    protected boolean eliminar(int idAsistencia) {
        return bdAsistencias.eliminar(idAsistencia);
    }

    @Override
    protected LinkedList<Asistencia> obtenerTodos() {
        return bdAsistencias.obtenerTodos();
    }
}
