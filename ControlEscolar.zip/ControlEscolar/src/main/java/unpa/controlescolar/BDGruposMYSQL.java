package unpa.controlescolar;

import java.sql.*;
import java.util.LinkedList;

public class BDGruposMYSQL {

    public LinkedList<Grupo> obtenerTodos() {
        String sql = "SELECT * FROM Grupo";
        LinkedList<Grupo> lista = null;
        MYSQL mysql = new MYSQL();
        ResultSet r = mysql.ejecutarQuery(sql);
        if (r != null) {
            try {
                lista = new LinkedList<>();
                while (r.next()) {
                    int id = r.getInt("id");
                    String nombre = r.getString("nombre");

                    lista.add(new Grupo(id, nombre));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return lista;
    }

    public Grupo obtener(int id) {
        String sql = "SELECT * FROM Grupo WHERE id=" + id;
        MYSQL mysql = new MYSQL();
        ResultSet rs = mysql.ejecutarQuery(sql);
        Grupo grupo = null;
        try {
            if (rs.next()) {
                String nombre = rs.getString("nombre");
                grupo = new Grupo(id, nombre);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return grupo;
    }

    public boolean eliminar(int idGrupo) {
        String sql = "DELETE FROM Grupo WHERE id=" + idGrupo;
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean actualizar(Grupo grupo) {
        String sql = "UPDATE Grupo SET nombre='"
                + grupo.getNombre() + "' WHERE id="
                + grupo.getId();
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean registrar(Grupo grupo) {
        String sql = "INSERT INTO Grupo (nombre) VALUES ('"
                + grupo.getNombre() + "')";
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }
}
