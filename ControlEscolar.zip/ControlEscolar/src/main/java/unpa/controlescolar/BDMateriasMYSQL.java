package unpa.controlescolar;

import java.sql.*;
import java.util.LinkedList;

public class BDMateriasMYSQL {

    public LinkedList<Materia> obtenerTodos() {
        String sql = "SELECT * FROM Materias";
        LinkedList<Materia> lista = null;
        MYSQL mysql = new MYSQL();
        ResultSet r = mysql.ejecutarQuery(sql);
        if (r != null) {
            try {
                lista = new LinkedList<>();
                while (r.next()) {
                    int id = r.getInt("id");
                    String nombre = r.getString("nombre");

                    lista.add(new Materia(id, nombre));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return lista;
    }

   public Materia obtener(int id) {
        String sql = "SELECT * FROM Materias WHERE id=" + id;
        MYSQL mysql = new MYSQL();
        ResultSet rs = mysql.ejecutarQuery(sql);
        Materia materia = null;
        try {
            if (rs.next()) {
                String nombre = rs.getString("nombre");
                materia = new Materia(id, nombre);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return materia;
    }

    public boolean eliminar(int idMateria) {
        String sql = "DELETE FROM Materias WHERE id=" + idMateria;
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean actualizar(Materia materia) {
        String sql = "UPDATE Materias SET nombre='"
                + materia.getNombre() + "' WHERE id="
                + materia.getId();
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean registrar(Materia materia) {
        String sql = "INSERT INTO Materias (nombre) VALUES ('"
                + materia.getNombre() + "')";
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }
}
