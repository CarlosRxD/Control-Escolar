package unpa.controlescolar;

import java.sql.*;
import java.util.LinkedList;

public class BDAsistenciasMYSQL {

    public LinkedList<Asistencia> obtenerTodos() {
        String sql = "SELECT * FROM Asistencia";
        LinkedList<Asistencia> lista = null;
        MYSQL mysql = new MYSQL();
        ResultSet r = mysql.ejecutarQuery(sql);
        if (r != null) {
            try {
                lista = new LinkedList<>();
                while (r.next()) {
                    int id = r.getInt("id");
                    int idAlumno = r.getInt("id_alumno");
                    Date fecha = r.getDate("fecha");
                    boolean presente = r.getBoolean("presente");

                    lista.add(new Asistencia(id, idAlumno, fecha, presente));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return lista;
    }

    
    public Asistencia obtener(int id) {
        String sql = "SELECT * FROM Asistencia WHERE id=" + id;
        MYSQL mysql = new MYSQL();
        ResultSet rs = mysql.ejecutarQuery(sql);
        Asistencia asistencia = null;
        try {
            if (rs.next()) {
                int idAsistencia = rs.getInt("id");
                int idAlumno = rs.getInt("id_alumno");
                Date fecha = rs.getDate("fecha");
                boolean presente = rs.getBoolean("presente");
                asistencia = new Asistencia(idAsistencia, idAlumno, fecha, presente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return asistencia;
    }


    public boolean eliminar(int idAsistencia) {
        String sql = "DELETE FROM Asistencia WHERE id=" + idAsistencia;
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean actualizar(Asistencia asistencia) {
        String sql = "UPDATE Asistencia SET id_alumno="
                + asistencia.getIdAlumno() + ", fecha='"
                + asistencia.getFecha() + "', presente="
                + asistencia.isPresente() + " WHERE id="
                + asistencia.getId();
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean registrar(Asistencia asistencia) {
        String sql = "INSERT INTO Asistencia (id_alumno, fecha, presente) VALUES ("
                + asistencia.getIdAlumno() + ",'"
                + asistencia.getFecha() + "',"
                + asistencia.isPresente() + ")";
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }
}
