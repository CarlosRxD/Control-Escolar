/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unpa.controlescolar;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import static unpa.controlescolar.ModeloAlumnos.obtenerPorGrupo;

/**
 *
 * @author cardo
 */
public class ModeloAsistencia {

    private static final GestionarAsistencias controladorAsistencias = new GestionarAsistencias();
    private static final GestionarGrupos controladorGrupos = new GestionarGrupos();
    private static final GestionarAlumnos controladorAlumnos = new GestionarAlumnos();

    public static void agregar(int idAlumno, Date fecha, boolean presente) {
        Asistencia asistencia = new Asistencia(idAlumno, fecha, presente);
        controladorAsistencias.agregar(asistencia);
    }

    public static void eliminar(int id) {
        controladorAsistencias.eliminar(id);
    }

    public static void actualizar(int id, int idAlumno, Date fecha, boolean presente) {
        Asistencia asistencia = new Asistencia(id, idAlumno, fecha, presente);
        controladorAsistencias.editar(asistencia);
    }

    public static LinkedList<Asistencia> obtenerPorGrupo(int idGrupo) {
        LinkedList<Asistencia> alumnos = controladorAsistencias.obtenerTodos();
        LinkedList<Asistencia> asistenciasFiltrados = new LinkedList<Asistencia>();

        for (Asistencia asistencia : alumnos) {
            Alumno alumno = controladorAlumnos.obtener(asistencia.getIdAlumno());
            if (alumno.getIdGrupo() == idGrupo) {
                asistenciasFiltrados.add(asistencia);
            }
        }

        return asistenciasFiltrados;
    }

    public static String obtenerTodo() {
        LinkedList<Asistencia> asistencias = controladorAsistencias.obtenerTodos();

        StringBuilder tabla = new StringBuilder();

        if (asistencias != null) {
            for (Asistencia asistencia : asistencias) {
                String presente = asistencia.isPresente() ? "Presente" : "Ausente";
                Alumno alumno = controladorAlumnos.obtener(asistencia.getIdAlumno());

                tabla.append("<tr>")
                        .append("<td>").append(alumno.getNombre()).append("</td>")
                        .append("<td>").append(presente).append("</td>")
                        .append("<td>").append(asistencia.getFecha()).append("</td>")
                        .append("<td>")
                        .append("<form method=\"post\" action=\"actualizarAsistencia.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtid\" name=\"txtid\" value=\"" + asistencia.getId() + "\">")
                        .append("<input class = \"btn btn-success\" type=\"submit\" value=\"Editar Asistencia\">")
                        .append("</form>")
                        .append("<form method=\"post\" action=\"eliminarAsistencia.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + asistencia.getId() + "\">")
                        .append("<input class = \"btn btn-danger\" type=\"submit\" value=\"Eliminar\">")
                        .append("</form>")
                        .append("</td>")
                        .append("</tr>");
            }
        }
        return tabla.toString();
    }

    public static String registrar(int id) {
        Alumno alumno = controladorAlumnos.obtener(id);

        StringBuilder formulario = new StringBuilder();
        formulario.append("<label for=\"nombre\">Nombre:</label>\n");
        formulario.append("<input type=\"text\" class=\"form-control\" id=\"nombre\" name=\"nombre\" value=\"" + alumno.getNombre() + "\" readonly>\n");
        formulario.append("<label for=\"presente\">Asistencia:</label>\n");
        formulario.append("<select class=\"form-control\" id=\"presente\" name=\"presente\">\n");
        formulario.append("    <option value=\"true\">Presente</option>\n");
        formulario.append("    <option value=\"false\">Ausente</option>\n");
        formulario.append("</select>\n");
        formulario.append("<label for=\"fecha\">Fecha:</label>\n");
        formulario.append("<input type=\"date\" id=\"fecha\" name=\"fecha\" >\n");
        return formulario.toString();
    }

    public static String obtenerActualizar(int id) {
        Asistencia asistencia = controladorAsistencias.obtener(id);
        Alumno alumno = controladorAlumnos.obtener(asistencia.getIdAlumno());

        String presente = asistencia.isPresente() ? "Presente" : "Ausente";

        StringBuilder formulario = new StringBuilder();
        formulario.append("<label for=\"nombre\">Nombre:</label>\n");
        formulario.append("<input type=\"hidden\"  id=\"idA\" name=\"idA\" value=\"" + alumno.getId()+ "\" readonly>\n");
        formulario.append("<input type=\"text\" class=\"form-control\" id=\"nombre\" name=\"nombre\" value=\"" + alumno.getNombre() + "\" readonly>\n");
        formulario.append("<label for=\"presente\">Asistencia:</label>\n");
        formulario.append("<select class=\"form-control\" id=\"presente\" name=\"presente\">\n");
        formulario.append("    <option value=\"" + asistencia.isPresente() + "\">" + presente + "</option>\n");
        formulario.append("    <option value=\"true\">Presente</option>\n");
        formulario.append("    <option value=\"false\">Ausente</option>\n");
        formulario.append("</select>\n");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaString = sdf.format(asistencia.getFecha());
        formulario.append("<input type=\"date\" id=\"fecha\" name=\"fecha\" value=\"" + fechaString + "\">\n");
        return formulario.toString();
    }

    public static String obtenerAsistenciaFiltradas(int idGrupo) {
        LinkedList<Asistencia> asistencias = obtenerPorGrupo(idGrupo);
        StringBuilder tabla = new StringBuilder();

        if (asistencias != null) {
            for (Asistencia asistencia : asistencias) {
                Alumno alumno = controladorAlumnos.obtener(asistencia.getIdAlumno());
                Grupo grupo = controladorGrupos.obtener(alumno.getIdGrupo());
                tabla.append("<tr>")
                        .append("<td>").append(alumno.getNombre()).append("</td>")
                        .append("<td>").append(asistencia.isPresente()).append("</td>")
                        .append("<td>").append(asistencia.getFecha()).append("</td>")
                        .append("<td>")
                        .append("<form method=\"post\" action=\"actualizarAsistencia.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtid\" name=\"txtid\" value=\"" + asistencia.getId() + "\">")
                        .append("<input class = \"btn btn-success\" type=\"submit\" value=\"Editar Asistencia\">")
                        .append("</form>")
                        .append("</td>")
                        .append("</tr>");
            }
        }
        return tabla.toString();
    }

    public static String obtenerAlumnos() {
        LinkedList<Alumno> alumnos = controladorAlumnos.obtenerTodos();

        StringBuilder tabla = new StringBuilder();

        if (alumnos != null) {
            for (Alumno alumno : alumnos) {
                tabla.append("<tr>")
                        .append("<td>").append(alumno.getNombre()).append("</td>")
                        .append("<td>").append(alumno.getMatricula()).append("</td>")
                        .append("<td>")
                        .append("<form method=\"post\" action=\"registrarAsistencia.jsp\">")
                        .append("<input type=\"hidden\" id=\"txtID\" name=\"txtID\" value=\"" + alumno.getId() + "\">")
                        .append("<input class = \"btn btn-success\" type=\"submit\" value=\"Marcar Asistencia\">")
                        .append("</form>")
                        .append("</td>")
                        .append("</tr>");
            }
        }
        return tabla.toString();
    }

}
