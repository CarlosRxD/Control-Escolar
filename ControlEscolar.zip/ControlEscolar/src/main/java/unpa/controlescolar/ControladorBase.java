package unpa.controlescolar;
import java.util.LinkedList;

public abstract class ControladorBase<T> {
    protected abstract LinkedList<T> obtenerTodos();
    protected abstract T obtener(int id);
    protected abstract boolean agregar(T objeto);
    protected abstract boolean editar(T objeto);
    protected abstract boolean eliminar(int id);
}

