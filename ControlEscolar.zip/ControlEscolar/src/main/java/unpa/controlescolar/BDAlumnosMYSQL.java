package unpa.controlescolar;

import java.sql.*;
import java.util.LinkedList;

public class BDAlumnosMYSQL {

    public LinkedList<Alumno> obtenerTodos() {
        String sql = "SELECT * FROM Alumno";
        LinkedList<Alumno> lista = new LinkedList<>();

        try (MYSQL mysql = new MYSQL(); ResultSet r = mysql.ejecutarQuery(sql)) {

            while (r.next()) {
                int id = r.getInt("id");
                String nombre = r.getString("nombre");
                String correo = r.getString("correo");
                int telefono = r.getInt("telefono");
                int matricula = r.getInt("matricula");
                int edad = r.getInt("edad");
                String sexo = r.getString("sexo");
                String tutor = r.getString("tutor");
                int telefonoTutor = r.getInt("telefono_tutor");
                int idGrupo = r.getInt("id_grupo");

                lista.add(new Alumno(id, nombre, correo, telefono, matricula, edad, sexo, tutor, telefonoTutor, idGrupo));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return lista;
    }

    public Alumno obtener(int id) {
        String sql = "SELECT * FROM Alumno WHERE id=" + id;
        MYSQL mysql = new MYSQL();
        ResultSet r = mysql.ejecutarQuery(sql);

        Alumno alumno = null;
        try {
            if (r.next()) {
                // Crear un objeto Alumno con los datos obtenidos de la consulta
                String nombre = r.getString("nombre");
                String correo = r.getString("correo");
                int telefono = r.getInt("telefono");
                int matricula = r.getInt("matricula");
                int edad = r.getInt("edad");
                String sexo = r.getString("sexo");
                String tutor = r.getString("tutor");
                int telefonoTutor = r.getInt("telefono_tutor");
                int idGrupo = r.getInt("id_grupo");
                alumno = new Alumno(id, nombre, correo, telefono, matricula, edad, sexo, tutor, telefonoTutor, idGrupo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alumno;
    }

    public boolean eliminar(int idAlumno) {
        String sql = "DELETE FROM Alumno WHERE id=" + idAlumno;
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean actualizar(Alumno alumno) {
        String sql = "UPDATE Alumno SET nombre='" + alumno.getNombre() + "', correo='" + alumno.getCorreo()
                + "', telefono='" + alumno.getTelefono() + "', matricula='" + alumno.getMatricula()
                + "',  edad='" + alumno.getEdad() + "',  sexo='" + alumno.getSexo() + "', tutor='"
                + alumno.getTutor() + "',  telefono_tutor='" + alumno.getTelefonoTutor()
                + "', id_grupo=" + alumno.getIdGrupo() + " WHERE id=" + alumno.getId();

        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

    public boolean registrar(Alumno alumno) {
        String sql = "INSERT INTO Alumno (nombre, correo, telefono, matricula, edad, sexo, tutor, telefono_tutor, id_grupo) VALUES ('"
                + alumno.getNombre() + "','"
                + alumno.getCorreo() + "','"
                + alumno.getTelefono() + "','"
                + alumno.getMatricula() + "','"
                + alumno.getEdad() + "','"
                + alumno.getSexo() + "','"
                + alumno.getTutor() + "','"
                + alumno.getTelefonoTutor() + "','"
                + alumno.getIdGrupo() + "')";
        System.out.println(sql);
        MYSQL mysql = new MYSQL();
        return mysql.ejecutarUpdate(sql);
    }

}
